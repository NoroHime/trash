NotifyOnNewObject("/Script/Pal.PalGameSetting", function(var)
	var.FlyHorizon_SP = 0
	var.FlyHorizon_Dash_SP = 0
	var.FlyHover_SP = 0
	var.FlyMaxHeight = 999999
	var.FlyVertical_SP = 0
end)
