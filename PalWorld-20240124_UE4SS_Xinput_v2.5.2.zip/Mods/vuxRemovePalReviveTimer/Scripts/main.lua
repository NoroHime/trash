NotifyOnNewObject("/Script/Pal.PalGameSetting", function(var)
	var.PalBoxReviveTime = 0
end)
